import './App.css';
import Main from './components/main.js';
import React from 'react';

export default function App()
{
  return(
    <>
      <Main/>
    </>
  );
}
